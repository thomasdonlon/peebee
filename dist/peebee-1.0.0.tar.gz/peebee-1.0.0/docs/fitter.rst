.. automodapi:: peebee.fitter
   :no-inheritance-diagram:
