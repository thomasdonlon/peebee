.. automodapi:: peebee.sampler
   :no-inheritance-diagram:
